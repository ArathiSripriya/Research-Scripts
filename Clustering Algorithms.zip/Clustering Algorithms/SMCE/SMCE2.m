function [idx,W] = SMCE2(S,varargin)

nVarargin = length(varargin);

[rows,cols] = size(S);
options = optimset('Simplex','on');

c0 = zeros(2*(cols-1),1);
C  = zeros(cols,cols);
for i = 1:cols
   
         A = [S - S(:,i)*ones(1,cols),-(S - S(:,i)*ones(1,cols))];
        nv = zeros(2*cols,1);
         Q = zeros(2*cols,1);
        for vec = 1:2*cols
            Q(vec) = norm(A(:,vec));
            if vec > cols
                Q(vec) = -1*Q(vec); 
            end
            if(vec == i || vec == i + cols);
                nv(vec) = 0;
            else
                nv(vec) = 1/norm(A(:,vec));
            end
        end
         Q = Q./sum(nv(1:cols));
         A = A*diag(nv);
         b = 0.01*norm(S(:,i))*ones(rows,1);
       Aeq = [ones(1,cols), -1*ones(1,cols);
              zeros(1,2*cols)];
       Aeq(2,i)      = 1; 
       Aeq(2,i+cols) = -1;
                 beq = [1;
                        0];
        lb = zeros(2*cols,1);
        ub = Inf(2*cols,1,'double');    
    [c,FEVAL,FLAG] = linprog(Q,A,b,Aeq,beq,lb,ub,c0,options);    
    if(FLAG < 0)
        fprintf('Linprog did not converge');
    end

    c0     = c; 
    cp     = c(1:cols) - c(cols+1:end);
    cinf   = norm(cp,Inf);
    C(:,i) = cp/cinf; 
    clc;
    fprintf('%3.2f percent complete',i/cols * 100);
    
end
fprintf('100 percent complete\n');

W = abs(C') + abs(C);

if(nVarargin == 0)
    maxk = 20;
    evs  = eigs(W,maxk);
    for i = 1:maxk
        k = i;
        if(evs(i) < 0.05*evs(1))
            break;
        end
    end
else
    k = varargin{1};
end
fprintf('*** Clustering into %d groups ***\n',k);
idx = SpectralClustering(W,k);

return 