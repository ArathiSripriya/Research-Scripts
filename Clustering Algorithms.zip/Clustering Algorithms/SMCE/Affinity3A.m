function [A] = Affinity3A(y)
%intended for the SMCE algorithm
[row,col] = size(y);
%n = length(y);
C = zeros(col,col); %why col specifically

for i = 1:col
    
    A = [y - y(:,i)*ones(1,col),-(y - y(:,i)*ones(1,col))]; %why perform the allocation in the loop
    y_row_norm = zeros(2*col,1);
    Q          = zeros(2*col,1);
    %what happened to removing the target?
    for j = 1:2*col 
        Q(j) = norm(A(:,j));
        if j > col
                Q(j) = -1*Q(j); 
        end
        if(j == i || j == i + col); %what is the purpose of the if statements
                y_row_norm(j) = 0;
        else
                y_row_norm(j) = 1/norm(A(:,j));
        end
    end
    Q        = Q./sum(y_row_norm(1:col));
    y_norm   = A * diag(y_row_norm);
    e        = 0.005*ones(row,1); %why was this altered in such a way
    Aeq = [ones(1,col), -1*ones(1,col);zeros(1,2*col)]; %inequalities weren't previously defined
    Aeq(2,i)      = 1; 
    Aeq(2,i+col)  = -1;
    beq = [1;0];
    lb       = zeros(2*col,1);
    ub       = Inf(2*col,1,'double');
    c_int    = linprog(Q,y_norm,e,Aeq,beq,lb,ub);
    c        = c_int(1:col) - c_int(col + 1:end);
    cinf     = norm(c,Inf); %steps following collapse appear new, why?
    cp       = c/cinf;
    for vec = 1:length(cp)
        if(cp(vec) < 0.005*max(cp))
            cp(vec) = 0;
        end
    end
    C(:,i)   = cp;  
    
end

%is it necessary to include the step relating k to eigs

A = abs(C) + abs(C');

return