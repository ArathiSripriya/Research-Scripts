function [A] = Affinity3(y)
%intended for the SMCE algorithm
n = length(y);
A = zeros(n);
C = [];
for i = 1:n
    
    y_int      = [y(1:i-1,:);y(i+1:end,:)];
    target     = y(i,:);
    y_tilde    = y_int - ones(n-1,1)*target;
    y_row_norm = zeros(n-1,1);
    Q          = zeros(2*(n-1),1); %2*
    for j = 1:n-1 %not n
        Q(j) = norm(y_tilde(j,:));
        y_row_norm(j)  = 1/norm(y_tilde(j,:));
    end
    Q(n:end) = -1*Q(1:n-1);
    Q        = Q./sum(y_row_norm);
    y_norm   = diag(y_row_norm) * y_tilde;
    Y        = [y_norm; -y_norm];
    e        = 0.01*ones(size(target));
    lb       = zeros(2*(n-1),1);
    ub       = Inf(2*(n-1),1,'double');
    c_int    = linprog(Q,Y',e',[],[],lb,ub);
    c        = c_int(1:n-1) - c_int(n:end);
    c        = [c(1:i-1);0;c(i:end)];
    C        = [C,c];  
    
end


A = abs(C) + abs(C)';

return