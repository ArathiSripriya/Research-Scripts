% clc
% clear
% close all

function [K,A] = SMCE(y,k)

%[y,k]        = Generate();
[A]          = Affinity3A(y);
[K]          = SpectralClustering(A,k);
%[S]         = SVD_Dim(K,k,y');

return