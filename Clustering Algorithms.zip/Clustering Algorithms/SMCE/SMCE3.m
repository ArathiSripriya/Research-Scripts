function [W] = SMCE3(S)

%nVarargin = length(varargin);
[rows,cols] = size(S);

C  = zeros(cols,cols);
for i = 1:cols
   
    A = S - S(:,i)*ones(1,cols);  % subtract current point from set
    A = [A(:,1:i-1), A(:,i+1:end)]; % remove point from array
    
    % allocate space for vector of norms and indice weights
    nv   = zeros(cols-1,1);
    Q    = zeros(cols-1,1);   
    Qinv = zeros(cols-1,1);
    for vec = 1:cols-1
        dummy = norm(A(:,vec));
        if(dummy > 1e-12)
            nv(vec) = 1/norm(A(:,vec));
        else
            nv(vec) = 0;
        end
        Q(vec) = dummy;
        
    end

    Q    = Q./sum(Q);
    for vec = 1:cols-1
        if(Q(vec) > 1e-12)
            Qinv(vec) = 1/Q(vec);
        else
            Qinv(vec) = 0;
        end
    end
    
    A = A*diag(nv);   % normalize shifted data points
    A = A*diag(Qinv); % add change of variables
    X = [A,-A];       % create dummy variables
    b = 0.0001*norm(S(:,i))*ones(rows,1); % set target vector to something small
    
    
    Aeq = [Qinv', -1*Qinv']; % account for change of variables
    beq = 1;
    
    lb = zeros(2*(cols-1),1);
    ub = Inf(2*(cols-1),1);  
        
    f  = ones(2*(cols-1),1);
    
    [c,FEVAL,FLAG] = linprog(f,X,b,Aeq,beq,lb,ub);  
    if(FLAG < 0)
        fprintf('Linprog did not converge, error code: %d\n', FLAG);
    end
    
    size(c)
    cp     = c(1:cols-1) - c(cols:end);
    cp     = diag(Qinv)*cp; % undo change of variables
    cp     = diag(Qinv)*cp;
    cp     = [cp(1:i-1); 0; cp(i:end)];

    for ind = 1:cols
        if cp(ind) < 0.005*max(cp)
            cp(ind) = 0;
        end
    end
    C(:,i) = cp./sum(cp); 
    fprintf('%3.2f percent complete',i/cols * 100); clc
    
end
fprintf('100 percent complete\n');

W = abs(C) + abs(C');

% if(nVarargin == 0)
%     maxk = 20;
%     evs  = eigs(W,maxk);
%     for i = 1:maxk
%         k = i;
%         if(evs(i) < 0.05*evs(1))
%             break;
%         end
%     end
% else
%     k = varargin{1};
% end
% fprintf('*** Clustering into %d groups ***\n',k);
% idx = SpectralClustering(W,k);

return 