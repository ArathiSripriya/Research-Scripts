function [A] = Affinity2(y)

n = length(y);
C = [];

for i = 1:n
    
    y_int  = [y(1:i-1,:);y(i+1:end,:)];
    Y      = [y_int, ones(n-1,1); -y_int,-1*ones(n-1,1)];
    target = [y(i,:),1];
    c_int  = linprog(ones(2*(n-1),1),[],[],Y',target',zeros(2*(n-1),1),Inf(2*(n-1),1,'double'));
    c      = c_int(1:n-1) - c_int(n:end);
    c      = [c(1:i-1);0;c(i:end)];
    C      = [C, c/norm(c,Inf)];
    
end

A = abs(C) + abs(C)';

return