% clc
% clear
% close all

function [K] = SSC(y,k)

%[y,k]        = Generate();
[A]         = Affinity2(y);
[K]         = SpectralClustering(A,k);
%[S]         = SVD_Dim(K,k,y');

return