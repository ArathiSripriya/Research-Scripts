function [A] = Affinity2A(y)

[row,col] = size(y);
C = zeros(col,col);

for i = 1:col
    
    y_int  = [y(1:i-1,:);y(i+1:end,:)];
    Y      = [y_int, ones(col-1,1); -y_int,-1*ones(col-1,1)];
    target = [y(i,:),1];
    c_int  = linprog(ones(2*(n-1),1),[],[],Y',target',zeros(2*(n-1),1),Inf(2*(n-1),1,'double'));
    c      = c_int(1:col) - c_int(col + 1:end);
    C(:,i)      = [C, c/norm(c,Inf)];
    
end

A = abs(C) + abs(C)';

return