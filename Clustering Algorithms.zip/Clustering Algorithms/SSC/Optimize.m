function [A] = Optimize(y)

n = length(y);
C = [];

for i = 1:n
    
    y_int = [y(1:i-1,:),y(i+1:end,:)];
    Y = [y_int,-y_int];
    target = y(i,:);
    c_int = linprog(ones(2*(n-1),1),Y',target',[],[],zeros(2*(n-1),1),Inf);
    c = c_int(1:n/2) - c_int(n/2 + 1:end);
    c = [c(1:i-1);0;c(i:end)];
    C = [C, c/norm(c,Inf)];
    
end

A = C + C';

return