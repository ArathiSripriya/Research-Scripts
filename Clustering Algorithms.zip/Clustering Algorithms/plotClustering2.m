%start 3d plot of data and color by cluster
figure
subplot(1,3,1)
plot3(Y(1,:),Y(2,:),Y(3,:),'bo')
grid on;
xlabel('x')
ylabel('y')
zlabel('z')
plotfixer

subplot(1,3,2)
plot3(Y(1,idx == 1),Y(2,idx == 1),Y(3,idx == 1),'ro'); hold on
plot3(centroids(1,1),centroids(1,2),centroids(1,3),'r*')
xlabel('x')
ylabel('y')
zlabel('z')
plotfixer

plot3(Y(1,idx == 2),Y(2,idx == 2),Y(3,idx == 2),'go');
plot3(centroids(2,1),centroids(2,2),centroids(2,3),'g*')
grid on;
xlabel('x')
ylabel('y')
zlabel('z')
plotfixer

subplot(1,3,3)
plot3(Y(1,idx2 == 1),Y(2,idx2 == 1),Y(3,idx2 == 1),'ro'); hold on
plot3(Y(1,idx2 == 2),Y(2,idx2 == 2),Y(3,idx2 == 2),'go');
grid on;
xlabel('x')
ylabel('y')
zlabel('z')

figure
plot3(Y(1,:),Y(2,:),Y(3,:),'b.')
grid on;
xlabel('x')
ylabel('y')
zlabel('z')
plotfixer

figure
plot3(Y(1,idx == 1),Y(2,idx == 1),Y(3,idx == 1),'ro'); hold on
plot3(centroids(1,1),centroids(1,2),centroids(1,3),'r*')
xlabel('x')
ylabel('y')
zlabel('z')

plot3(Y(1,idx == 2),Y(2,idx == 2),Y(3,idx == 2),'go');
plot3(centroids(2,1),centroids(2,2),centroids(2,3),'g*')
grid on;
xlabel('x')
ylabel('y')
zlabel('z')

figure
plot3(Y(1,idx2 == 1),Y(2,idx2 == 1),Y(3,idx2 == 1),'ro'); hold on
plot3(Y(1,idx2 == 2),Y(2,idx2 == 2),Y(3,idx2 == 2),'go');
grid on;
xlabel('x')
ylabel('y')
zlabel('z')

% figure(5)
% subplot(1,2,1)
% spy(W)
% title('Similarity Matrix')
% plotfixer
% % subplot(1,2,2)
% % for i = 1:k
% %     W(idx2 == i,idx2 == i) = i;
% % end
% % [R1,R2] = meshgrid(0:1:size(W,1)-1,0:1:size(W,2)-1);
% % contourf(R1,R2,W);
% % title('Clustering')
% % set(gca,'Ydir','reverse')
% 
% figure(6)
% ev = eigs(W,4*k);
% plot(abs(ev),'*')
% ylabel('\lambda')
% title('Eigenvalues of Similarity Matrix')
% grid on