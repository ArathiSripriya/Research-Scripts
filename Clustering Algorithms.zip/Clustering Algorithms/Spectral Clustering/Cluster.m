function [Y1] = Cluster(Y,k)

Y1 = kmeans(Y,k);
display(Y1)

return

