function [ Y ] = Renorm(X)
[r,c] = size(X);
Y = zeros(r,c);

for i = 1:r
        for j = 1:c          
                Y(i,j) = X(i,j)/sqrt(sum(X(i,:)).^2);
        end
 end
 
return

