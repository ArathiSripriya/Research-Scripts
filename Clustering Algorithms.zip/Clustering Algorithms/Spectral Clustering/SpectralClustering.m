
function [K,Y] = SpectralClustering(A,k)

%[y]         = Generate();
%[A]         = Affinity(y);
[L]         = Laplacian(A);
[X,Val]     = eigs(L,k);
[Y]         = Renorm(X);
figure
plot(Y(:,1),Y(:,2),'o')
[K]         = kmeans(Y,k); % is this applied row by row?

return