
function [A] = Affinity(y)
    n = length(y);
    a = tril(zeros(n),0);
    sigma = 1;
    for i = 1:n
        for j = 1:n
            if (j > i)
                scal = norm(y(i,:)-y(j,:))^2;
                a(i,j) = exp(-scal/(2*(sigma)^2));
            end
        end
    end
    
    A = a + a'; %isn't there a diagonal I should remove, to avoid repetition?
    
return