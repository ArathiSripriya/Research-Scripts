function[L] = Laplacian(A)
 n = length(A);
 D = zeros(n);
 
 for i = 1:n
        for j = 1:n
            if (i == j)
                D(i,j) = 1/sqrt(sum(A(i,:)));
            end
        end
 end
 
 L = (D)*A*(D);
 return
 
 