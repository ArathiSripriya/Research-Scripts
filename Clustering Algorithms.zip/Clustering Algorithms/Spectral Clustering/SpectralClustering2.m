function [idx] = SpectralClustering2(A,k)

% compute the Laplacian
n = size(A,1);
D = zeros(n,n);
for row = 1:n
    D(row,row) = 1/sqrt(sum(A(row,:)));
end

L = D*A*D;

% Compute the eigenvectors and eigen values
[U,V] = eigs(L,k); % ARPACK Eigensolver


% Renormalize the eigenvectors
Y = zeros(size(U));
for i=1:n       
    Y(i,:) = U(i,:)./norm(U(i,:),2); 
end

% cluster the rows of the renormalized eigenvectors
idx = kmeans(Y,k);

return 