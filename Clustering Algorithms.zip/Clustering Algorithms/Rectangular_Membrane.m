function varargout = Rectangular_Membrane(varargin)
% RECTANGULAR_MEMBRANE M-file for Rectangular_Membrane.fig
%      RECTANGULAR_MEMBRANE, by itself, creates a new RECTANGULAR_MEMBRANE or raises the existing
%      singleton*.
%
%      H = RECTANGULAR_MEMBRANE returns the handle to a new RECTANGULAR_MEMBRANE or the handle to
%      the existing singleton*.
%
% How to use the GUI
%    - Use the sliders in the top right panel to adjust the dimensions
%    of the membrane.
%    - Use the sliders in the "Single Mode (enter m, n)" panel 
%    to choose m and n, and to see the displacement corresponding
%    to the normal mode u_mn.
%    - Use the sliders in the panel labeled "Superposition of modes
%    (enter weights)" to select the weights of the first four normal
%    modes, u_mn with m,n = 1,2, and to see the displacement
%    associated with the corresponding linear combination.
%    - Click the "Run" button to see the time-evolution of the
%    membrane.
%    - Click the "Reset" button to reinitializes the GUI.
%
% Developed by Luis Garcia-Naranjo, Mathematics Department, University
% of Arizona, Spring 2007.
% 

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Rectangular_Membrane_OpeningFcn, ...
                   'gui_OutputFcn',  @Rectangular_Membrane_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Rectangular_Membrane is made visible.
function Rectangular_Membrane_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Rectangular_Membrane (see VARARGIN)

global x y

global  delta_t play multi_mode single_mode



% Choose default command line output for Rectangular_Membrane
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Rectangular_Membrane wait for user response (see UIRESUME)
% uiwait(handles.figure1);

set(handles.figure1,'Name',' Rectangular Elastic Membrane');
axes(handles.axes1)


delta_t = 0.03; % time step for simulation
play=0; % flag for running simulation

%Membrane dimensions
a=get(handles.slider_a,'Value');
set(handles.value_a,'String',a);
b=get(handles.slider_b,'Value');
set(handles.value_b,'String',b);

%Define coordinates for the membrane
[x,y]=meshgrid( (0:0.01:1)*a, (0:0.01:1)*b);

% Flat Membrane
mesh(x,y,zeros(size(x)));
zlim([-7 7])
xlim([0 10])
ylim([0 10])
axis off
%rotate3d ---> Enable this feature is in Stand by.


%Set slider Values at the beginning

m=get(handles.slider_m,'Value');
set(handles.value_m,'String',m);
n=get(handles.slider_n,'Value');
set(handles.value_n,'String',n);


a_11=get(handles.slider_11,'Value');
set(handles.value_11,'String',a_11);

a_12=get(handles.slider_12,'Value');
set(handles.value_12,'String',a_12);


a_21=get(handles.slider_21,'Value');
set(handles.value_21,'String',a_21);

a_22=get(handles.slider_22,'Value');
set(handles.value_22,'String',a_22);


%Set initial condition for single
%mode feature.

function initial_single(hObject,eventdata,handles)

global x y

global  play multi_mode single_mode

single_mode=1; %flag for single-mode feature

multi_mode=0;  %flag for multi-mode feature 

play=0;        %flag to run simulation  


%Obtain wave vector of single mode
m=get(handles.slider_m,'Value');
m=round(m);
set(handles.value_m,'String',m);
n=get(handles.slider_n,'Value');
n=round(n);
set(handles.value_n,'String',n);


%Obtain dimensions of the membrane
a=get(handles.slider_a,'Value');
set(handles.value_a,'String',a);
b=get(handles.slider_b,'Value');
set(handles.value_b,'String',b);


%Set the values of the multi-mode sliders to zero
set(handles.slider_11,'Value',0);
set(handles.value_11,'String',0);

set(handles.slider_12,'Value',0);
set(handles.value_12,'String',0);


set(handles.slider_21,'Value',0);
set(handles.value_21,'String',0);

set(handles.slider_22,'Value',0);
set(handles.value_22,'String',0);


%Define coordinates for the membrane
[x,y]=meshgrid( (0:0.01:1)*a, (0:0.01:1)*b);

%Shape of the membrane
u = 5*sin(m*pi*x/a).*sin(n*pi*y/b);

%Plot the membrane
mesh(x,y,u);
zlim([-7 7])
xlim([0 10])
ylim([0 10])
axis off
%rotate3d -----> Enabling this feature is in Stand by





%Set initial condition for multi-mode feature.

function initial_multi(hObject,eventdata,handles)

global x y

global  play multi_mode single_mode

single_mode=0; %flag for single-mode feature

multi_mode=1;  %flag for multi-mode feature

play=0;        %flag to run simulation

%Obtain weights for different modes
a11=get(handles.slider_11,'Value');
set(handles.value_11,'String',a11);

a12=get(handles.slider_12,'Value');
set(handles.value_12,'String',a12);


a21=get(handles.slider_21,'Value');
set(handles.value_21,'String',a21);

a22=get(handles.slider_22,'Value');
set(handles.value_22,'String',a22);


%Obtain dimensions of the membrane
a=get(handles.slider_a,'Value');
set(handles.value_a,'String',a);
b=get(handles.slider_b,'Value');
set(handles.value_b,'String',b);


%Set sliders of single-mode feature to zero
set(handles.slider_m,'Value',0);
set(handles.value_m,'String',0);

set(handles.slider_n,'Value',0);
set(handles.value_n,'String',0);


%Define coordinates for the membrane
[x,y]=meshgrid( (0:0.01:1)*a, (0:0.01:1)*b);

%Define membrane shape
u = a11*sin(pi*x/a).*sin(pi*y/b)+a12*sin(pi*x/a).*sin(2*pi*y/b)+a21*sin(2*pi*x/a).*sin(pi*y/b)+a22*sin(2*pi*x/a).*sin(2*pi*y/b);

%plot membrane
mesh(x,y,u);
zlim([-7 7])
xlim([0 10])
ylim([0 10])
axis off
%rotate3d ------> Enabling this feature is in stand by




%Time evolution of the modes
function evolve(hObject,eventdata,handles)

global x y

global c delta_t play multi_mode single_mode %speed & flags

play=1;  %flag for running simulation

%Determine membrane dimensions
a=get(handles.slider_a,'Value'); 
b=get(handles.slider_b,'Value');

c=(a+b)/2;  %Value of c in the equation u_tt=c^2*Lap(u)
            %Speed equals characteristic length scale (a+b)/2
            %We take T=1 as characteristic time scale.
            
            
            
%Define coordinates for the membrane
[x,y]=meshgrid( (0:0.01:1)*a, (0:0.01:1)*b);

%Run simulation if multi-mode feature is activated
if multi_mode==1
    
    %Determine weights of the initial condition and frequencies of 
    %oscillation of the different modes
    a11=get(handles.slider_11,'Value');
    lambda_11=c*pi*sqrt((1/a)^2+(1/b)^2);

    a12=get(handles.slider_12,'Value');
    lambda_12=c*pi*sqrt((1/a)^2+(2/b)^2);

    a21=get(handles.slider_21,'Value');
    lambda_21=c*pi*sqrt((2/a)^2+(1/b)^2);
    
    a22=get(handles.slider_22,'Value');
    lambda_22=c*pi*sqrt((2/a)^2+(2/b)^2);
    
    %Evolve
    for t=0:delta_t:30
        if play==0  %Stop simulation if other buttons or sliders are activated
            break
        end
        u = a11*cos(lambda_11*t)*sin(pi*x/a).*sin(pi*y/b)+a12*cos(lambda_12*t)*sin(pi*x/a).*sin(2*pi*y/b)+a21*cos(lambda_21*t)*sin(2*pi*x/a).*sin(pi*y/b)+a22*cos(lambda_22*t)*sin(2*pi*x/a).*sin(2*pi*y/b);
        mesh(x,y,u);
        zlim([-7 7])
        xlim([0 10])
        ylim([0 10])
        axis off

        pause(0.15) %Pause to see image
    end
    %Plot back the initial condition or flat membrane if the reset button
    %was pushed
    
    a11=get(handles.slider_11,'Value');
    a12=get(handles.slider_12,'Value');
    a21=get(handles.slider_21,'Value');
    a22=get(handles.slider_22,'Value');
    
    u = a11*sin(pi*x/a).*sin(pi*y/b)+a12*sin(pi*x/a).*sin(2*pi*y/b)+a21*sin(2*pi*x/a).*sin(pi*y/b)+a22*sin(2*pi*x/a).*sin(2*pi*y/b);
        mesh(x,y,u);
        zlim([-7 7])
        xlim([0 10])
        ylim([0 10])
        axis off
end


%Run simulation if single-mode feature is activated
if single_mode==1
    
    %Determine mode to be evolved
    m=get(handles.slider_m,'Value');
    m=round(m);
    
    n=get(handles.slider_n,'Value');
    n=round(n);
    
    %Determine frequency of oscillation
    lambda_mn=c*pi*sqrt( (m/a)^2 + (n/b)^2);
    
    %evolve
    for t=0:delta_t:30
        if play==0
            break %Stop simulation if other buttons or sliders are activated
        end
        u = 5*cos(lambda_mn*t)*sin(m*pi*x/a).*sin(n*pi*y/b);
        mesh(x,y,u);
        zlim([-7 7])
        xlim([0 10])
        ylim([0 10])
        axis off

        pause(0.15) %pause to see image
    end
    %Plot back the initial condition
    m=get(handles.slider_m,'Value');
    m=round(m);
    n=get(handles.slider_n,'Value');
    n=round(n);
    u = 5*sin(m*pi*x/a).*sin(n*pi*y/b);
    mesh(x,y,u);
    zlim([-7 7])
    xlim([0 10])
    ylim([0 10])
    axis off
end




% --- Outputs from this function are returned to the command line.
function varargout = Rectangular_Membrane_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function slider_m_Callback(hObject, eventdata, handles)
% hObject    handle to slider_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

initial_single(hObject,eventdata,handles)


% --- Executes during object creation, after setting all properties.
function slider_m_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider_n_Callback(hObject, eventdata, handles)
% hObject    handle to slider_n (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

initial_single(hObject,eventdata,handles)

% --- Executes during object creation, after setting all properties.
function slider_n_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_n (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function value_m_Callback(hObject, eventdata, handles)
% hObject    handle to value_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of value_m as text
%        str2double(get(hObject,'String')) returns contents of value_m as a double


% --- Executes during object creation, after setting all properties.
function value_m_CreateFcn(hObject, eventdata, handles)
% hObject    handle to value_m (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function value_n_Callback(hObject, eventdata, handles)
% hObject    handle to value_n (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of value_n as text
%        str2double(get(hObject,'String')) returns contents of value_n as a double


% --- Executes during object creation, after setting all properties.
function value_n_CreateFcn(hObject, eventdata, handles)
% hObject    handle to value_n (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider_a_Callback(hObject, eventdata, handles)
% hObject    handle to slider_a (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

global  play multi_mode single_mode

play=0;

if get(handles.slider_a,'Value') < 0.5
    set(handles.slider_a,'Value',0.5);
end

if multi_mode==1
    initial_multi(hObject,eventdata,handles)
end

if single_mode==1
    initial_single(hObject,eventdata,handles)
end


% --- Executes during object creation, after setting all properties.
function slider_a_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_a (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider_b_Callback(hObject, eventdata, handles)
% hObject    handle to slider_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

global  play multi_mode single_mode

play=0;

if get(handles.slider_b,'Value') < 0.5
    set(handles.slider_b,'Value',0.5);
end

if multi_mode==1
    initial_multi(hObject,eventdata,handles)
end

if single_mode==1
    initial_single(hObject,eventdata,handles)
end


% --- Executes during object creation, after setting all properties.
function slider_b_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function value_a_Callback(hObject, eventdata, handles)
% hObject    handle to value_a (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of value_a as text
%        str2double(get(hObject,'String')) returns contents of value_a as a double


% --- Executes during object creation, after setting all properties.
function value_a_CreateFcn(hObject, eventdata, handles)
% hObject    handle to value_a (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function value_b_Callback(hObject, eventdata, handles)
% hObject    handle to value_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of value_b as text
%        str2double(get(hObject,'String')) returns contents of value_b as a double


% --- Executes during object creation, after setting all properties.
function value_b_CreateFcn(hObject, eventdata, handles)
% hObject    handle to value_b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider_11_Callback(hObject, eventdata, handles)
% hObject    handle to slider_11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

initial_multi(hObject,eventdata,handles)

% --- Executes during object creation, after setting all properties.
function slider_11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider_12_Callback(hObject, eventdata, handles)
% hObject    handle to slider_12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

initial_multi(hObject,eventdata,handles)

% --- Executes during object creation, after setting all properties.
function slider_12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider_21_Callback(hObject, eventdata, handles)
% hObject    handle to slider_21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

initial_multi(hObject,eventdata,handles)

% --- Executes during object creation, after setting all properties.
function slider_21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider_22_Callback(hObject, eventdata, handles)
% hObject    handle to slider_22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

initial_multi(hObject,eventdata,handles)

% --- Executes during object creation, after setting all properties.
function slider_22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function value_11_Callback(hObject, eventdata, handles)
% hObject    handle to value_11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of value_11 as text
%        str2double(get(hObject,'String')) returns contents of value_11 as a double


% --- Executes during object creation, after setting all properties.
function value_11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to value_11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function value_12_Callback(hObject, eventdata, handles)
% hObject    handle to value_12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of value_12 as text
%        str2double(get(hObject,'String')) returns contents of value_12 as a double


% --- Executes during object creation, after setting all properties.
function value_12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to value_12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function value_21_Callback(hObject, eventdata, handles)
% hObject    handle to value_21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of value_21 as text
%        str2double(get(hObject,'String')) returns contents of value_21 as a double


% --- Executes during object creation, after setting all properties.
function value_21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to value_21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function value_22_Callback(hObject, eventdata, handles)
% hObject    handle to value_22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of value_22 as text
%        str2double(get(hObject,'String')) returns contents of value_22 as a double


% --- Executes during object creation, after setting all properties.
function value_22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to value_22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Runbutton.
function Runbutton_Callback(hObject, eventdata, handles)
% hObject    handle to Runbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

evolve(hObject,eventdata,handles)

% --- Executes on button press in Resetbutton.
function Resetbutton_Callback(hObject, eventdata, handles)
% hObject    handle to Resetbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



global  play

play=0;



set(handles.slider_m,'Value',0);
set(handles.value_m,'String',0);

set(handles.slider_n,'Value',0);
set(handles.value_n,'String',0);


set(handles.slider_11,'Value',0);
set(handles.value_11,'String',0);

set(handles.slider_12,'Value',0);
set(handles.value_12,'String',0);


set(handles.slider_21,'Value',0);
set(handles.value_21,'String',0);

set(handles.slider_22,'Value',0);
set(handles.value_22,'String',0);


set(handles.slider_a,'Value',10);
set(handles.value_a,'String',10);

set(handles.slider_b,'Value',10);
set(handles.value_b,'String',10);

% Flat Membrane
[x,y]=meshgrid( (0:0.01:1)*10, (0:0.01:1)*10);

mesh(x,y,zeros(size(x)));
zlim([-7 7])
zlim([-7 7])
xlim([0 10])
ylim([0 10])
axis off
