clc
clear
close all

addpath('SparseSubspace','SpectralCluster','SMCE')

N     = 6;   % embedding space (3)
ss    = 2;   % subspace size (1)
k     = 2;   % number of clusters (2)
Ns    = 150; % number of snapshots per subspace (100)
extra = 0;   % this is not really useful

% build the data in random subspaces in embedding space
Y = []; % snapshot matrix
for i = 1:k
    [P,dummy] = qr(rand(N,ss),0); % get random subspace in R^N
       offset = 0.1*rand(N,1);
    for n = 1:Ns
        snapshot = 1*P*(rand(ss,1) - 0.5) + offset;
               Y = [Y,snapshot];
    end
end

% Y1 = Generate2(); k = 3; Y = Y1';

% here is were your clustering implementations go
[idx,centroids] = kmeans(Y',k);
[W]             = SMCE3(Y);
[idx2]          = SpectralClustering(W,k);
%[idx2] = SSC(Y',k);
% W = zeros(length(idx2),length(idx2));

figure
for i = 1:k
    svk   = svd(Y(:,idx  == i));
    svssc = svd(Y(:,idx2 == i));
    subplot(k,1,i)
    semilogy(1:length(svk),svk,'*-',1:length(svssc),svssc,'s-');
    title([{'Cluster'},num2str(i)]);
    ylabel('\sigma')
    legend('Kmeans','SSC')
    grid on
end

plotClustering2