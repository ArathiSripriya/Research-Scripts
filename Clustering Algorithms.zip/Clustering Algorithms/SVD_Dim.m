function [S] = SVD_Dim(K,k,y) %function needs multiple outputs in prior call

S = [];

dim_num = rank(y);

display(dim_num);

for i =1:k
    
    s = svd(y(:,K == i));
    S = [S,length(s)]; %returns rank for each cluster #
    display('Cluster:')
    display(i)
    display(length(s))
    
end

return