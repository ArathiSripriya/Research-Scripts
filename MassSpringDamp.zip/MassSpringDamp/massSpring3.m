function dydt = massSpring3(t,y,M,S,F)

    N                 = length(y);
    dydt              = zeros(N,1); %alter size for corresponding number of dimensions?
    dydt(1:(N/2))     = y(((N/2)+1):N); 
    dydt(((N/2)+1):N) = M\(-1*S*y(1:(N/2))+F); %removed D, which was multiplied by y(((N/2)+1):N)
    
return