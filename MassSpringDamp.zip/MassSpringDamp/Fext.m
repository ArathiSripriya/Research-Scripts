function [F] = Fext(t,mass_no)

F = zeros(mass_no,1);

if(t > 0.5)
    F(end) = -600;
else
    F = 10*ones(mass_no,1);
end

% display(F)
return