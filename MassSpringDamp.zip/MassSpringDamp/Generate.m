function [y] = Generate()
    prompt1 = 'How many masses would you like to simulate? Must be > 1. ';
    mass_no = input(prompt1);

    m1 = rand(mass_no,1);
    M  = diag(m1);

    display(M)

    %Fill spring constant matrix
    
    % functional only for individual oscillating masses
    %s = rand(mass_no,1);
    %S  = diag(s);
        
%       % # of springs > # of masses
%     s  = rand(mass_no + 1,1); 
%     row = length(s);
%     S = zeros(mass_no,mass_no);
%     
%     for i = 1:length(S)
%          for j = 1:length(S)
%             if(i == j + 1)
%                 S(i,j) = -s(i); 
%             elseif(i == j && i <= row - 1)
%                 S(i,j) = s(i) + s(i+1);
%             end
%          end      
%     end
    
      % # of masses > # of springs
    s  = rand(mass_no - 1,1); 
    row = length(s);
    
    S  = zeros(mass_no,mass_no);
     
    S(1,1) = s(1);
    S(mass_no,mass_no) = s(row);

    for i = 1:length(S)
        for j = 1:length(S)
            if(i == j + 1 && i <= row)
                S(i,j) = -s(i-1);
            elseif(i == j + 1 && i == row + 1)
                S(i,j) = -s(row);
            elseif(i > 1 && i <= row && i==j)
                S(i,j) = s(i) + s(i-1);
            end    
        end
    end
    
    S = tril(S)+tril(S,-1)';
    
    display(S)

    %Fill damper constant matrix
        
    %for individual oscillating dampers
    %d1 = rand(mass_no,1);
    %D  = diag(d1);

    %display(D)

    %Fill initial positions/velocities vector (How do I scale to multiple dimensions?)

    P_V = rand(mass_no * 2,1);
    display(P_V)
    
    %Fill external force vector
    F = rand(mass_no,1);
    display(F)

    [t,y] = ode45(@(t,y) massSpring2(t,y,M,S,F), [0,20], P_V); %removed D
    %N     = length(P_V);
    % plot(t,y(:,1:N/2),'-o',t,y(:,N/2 + 1:N),'-*')
    % xlabel('time (s)')
    % ylabel('y or ydot')
    % legend('y','ydot')
    % grid on;
    
%     prompt2 = 'How many clusters would you like to simulate? Must be <= number of masses. ';
%     k = input(prompt2);
    
return
