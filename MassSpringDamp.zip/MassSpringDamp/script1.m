%Fill masses matrix

prompt1 = 'How many masses would you like to simulate? ';
mass_no = input(prompt1);

M = eye(mass_no); %Generates an identity matrix 

for i = 1:numel(M)
    if M(i) == 1
      prompt2 = 'Enter the mass value? ';
      M(i) = input(prompt2);  
    end
end

display(M)

%Fill spring constant matrix

S = zeros(mass_no);
[r,c] = size(S);

for row = 1:r %Is there an easier way to create and store the spring array symmetrically?
    for column = 1:c
        if (row == column + 1) || (row == column - 1)
            display(row); 
            display(column);
            prompt3 = 'Enter spring constant for connected masses. ';
            S(row,column) = input(prompt3);
         %Is it possible to eliminate redundancy between two of the same types of masses?
        end       
    end    
end

display(S)

%Fill damper constant matrix

D = zeros(mass_no);
[ro,col] = size(D);

for row = 1:ro 
    for column = 1:col
        if (row == column + 1) || (row == column - 1)
            display(row); 
            display(column);
            prompt4 = 'Enter damper constant for connected masses. ';
            D(row,column) = input(prompt4);
        end       
    end    
end

display(D)

%Fill initial positions matrix (How do I scale to multiple dimensions?)

prompt5 = 'Enter the number of dimensions you would like to simulate. ';
dim_num = input(prompt5);
P = zeros(mass_no,dim_num);
[m,d] = size(P);

for i = 1:m
    fprintf('Dimension %d',i);
    for j = 1:d
        prompt6 = 'Enter the initial position of each mass. ';
        P(i,j) = input(prompt6);
    end
end

display(P)

%Fill initial velocities matrix

V = zeros(mass_no,dim_num);
[v,dim] = size(V);

for i = 1:v
    fprintf('Dimension %d',i);
    for j = i:dim
        prompt7 = 'Enter the initial velocity of each mass. ';
        V(i,j) = input(prompt7);
    end
end

display(V)

%Create empty acceleration matrix
     
        




     
