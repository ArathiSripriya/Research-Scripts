
function dydt = massSpring(t,y,m,s,d)
    dydt    = zeros(2,1); %alter size for corresponding number of dimensions?
    dydt(1) = y(2); 
    dydt(2) = (-s*y(1) - d*y(2))/m; %place this in terms of Euler to solve matrices?
    
return
    
