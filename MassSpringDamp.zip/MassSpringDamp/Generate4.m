function [y,k] = Generate4()

m1 = rand(4,1);
M  = diag(m1);

display(M)

s = rand(3,1);
S = zeros(4,4);

S(1,1) = s(1);
S(2,2) = s(1) + s(2);
S(3,3) = s(2) + s(3);
S(4,4) = s(3);

S(2,1) = -s(1);
S(3,2) = -s(2);
S(4,3) = -s(3);

S = tril(S)+tril(S,-1)';
    
display(S)

P_V = rand(4 * 2,1);
display(P_V)
    
    
    F = rand(4,1);
    display(F)

    [t,y] = ode45(@(t,y) massSpring2(t,y,M,S,F), [0,20], P_V); %removed D
    %N     = length(P_V);
    % plot(t,y(:,1:N/2),'-o',t,y(:,N/2 + 1:N),'-*')
    % xlabel('time (s)')
    % ylabel('y or ydot')
    % legend('y','ydot')
    % grid on;
    
    prompt2 = 'How many clusters would you like to simulate? Must be <= 4. ';
    k = input(prompt2);

    