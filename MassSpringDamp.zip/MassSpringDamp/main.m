clc
clear
close all

 m = 10;
 s = 6;
 d = 5;
% [t,y] = ode45(@(t,y) massSpring(t,y,m,s,d), [0,20], [5,10]);
% plot(t,y(:,1),'-o',t,y(:,2),'-*')
% xlabel('time (s)')
% ylabel('y or ydot')
% legend('y','ydot')
% grid on;

[y] = Generate();

%how do replicates, local minima, and repeating centroids come into play for kmeans? 

[A] = Affinity(y);

[L] = Laplacian(A);

k = 10;

[X,Val] = eigs(L,k);
[Y] = Vex(X);

[Y1] = Cluster(Y,k);
%Eventually alter to take input from a file
