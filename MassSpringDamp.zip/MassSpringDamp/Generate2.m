function [y] = Generate2()
    prompt1 = 'How many masses would you like to simulate? Must be > 1. ';
    mass_no = input(prompt1);
    
    m1 = 100*ones(mass_no,1);
    M  = diag(m1);

    display(M)

    %Fill spring constant matrix
    
    % functional only for individual oscillating masses
    %s = rand(mass_no,1);
    %S  = diag(s);
        
%       % # of springs > # of masses
%     s  = rand(mass_no + 1,1); 
%     row = length(s);
%     S = zeros(mass_no,mass_no);
%     
%     for i = 1:length(S)
%          for j = 1:length(S)
%             if(i == j + 1)
%                 S(i,j) = -s(i); 
%             elseif(i == j && i <= row - 1)
%                 S(i,j) = s(i) + s(i+1);
%             end
%          end      
%     end
    
      % # of masses > # of springs
    s  = rand(mass_no - 1,1); 
    row = length(s);
    
    S  = zeros(mass_no,mass_no);
     
    S(1,1) = s(1);
    S(mass_no,mass_no) = s(row);

    for i = 1:length(S)
        for j = 1:length(S)
            if(i == j + 1)
                if(i <= row)
                    S(i,j) = -s(i-1);
                elseif(i == row + 1)
                    S(i,j) = -s(row);
                end
            elseif(i==j && i > 1 && i <= row)
                S(i,j) = s(i) + s(i-1);
            end    
        end
    end
    
    S = tril(S)+tril(S,-1)';
    
    display(S)

    %Fill initial positions/velocities vector (How do I scale to multiple dimensions?)

    P_V = rand(mass_no * 2,1);
    display(P_V)
    
    M
    S
            
    [t,y] = ode45(@(t,y) massSpring3(t,y,M,S,Fext(t,mass_no)), [0,1], P_V); %removed damping, 
    N     = length(P_V);
    figure
    plot(t,y(:,1:N/2),'-ro',t,y(:,N/2 + 1:N),'-b*')
    xlabel('time (s)')
    ylabel('y or ydot')
    legend('y','ydot')
    grid on;
    
    figure
    plot(y(:,1),y(:,2));
    grid on
    
%     prompt2 = 'How many clusters would you like to simulate? Must be <= number of masses. ';
%     k = input(prompt2);
    
return
